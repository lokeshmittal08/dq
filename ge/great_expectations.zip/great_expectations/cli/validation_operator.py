# TODO remove this module when cli.v012 is deprecated
# Hacks to simplify help usage.
validation_operator = None
