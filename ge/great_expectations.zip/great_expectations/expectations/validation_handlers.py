import logging

logger = logging.getLogger(__name__)


class MetaPandasDataset:
    def column_map_expectation(self) -> None:
        logger.debug("MetaPandasDataset.column_map_expectation")
